import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  
  const [ID, setID] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    setTimeout(() => {
      if ( ID === 'admin','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20') {
        alert('Login successful!');
        navigate('/');
      }
      
       else {
        alert('Invalid credentials. Please try again.');
      }
    }, 1000);
  };

  return (
    <div className="content">
      <h2>Login</h2>
      <form onSubmit={handleLogin} className="form-group">
        
        <input
          type="ID"
          placeholder="ID"
          className="form-control"
          value={ID}
          onChange={(e) => setID(e.target.value)}
        />
        <button type="submit" className="btn">Login</button>
      </form>
    </div>
  );
}

export default Login;