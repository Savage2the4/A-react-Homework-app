import React, { useState } from "react";
import Cards from "./Card";
import axios from 'axios';


function AddTasks() {
  // State to store pending tasks and done tasks
  const [tasks, Settasks] = useState([]);
  const [doneTasks, SetdoneTasks] = useState([]);
  const [newtasks, Setnewtasks] = useState("");

  // Handle input change for new tasks
  function handle(event) {
    Setnewtasks(event.target.value);
  }

  // Delete a task from the pending list
  function DeleteTask(index) {
    const updatedTask = tasks.filter((element, i) => i !== index);
    Settasks(updatedTask);
  }

  // Add a new task to the pending list
  function addtask() {
    if (newtasks.trim() !== "") {
      Settasks(t => [...t, newtasks]);
      Setnewtasks("");
    }
  }

  // Move a task from the pending list to the done list
  function Movetodone(index) {
    // Get the task that needs to be moved
    const taskToMove = tasks[index];
    
    // Remove the task from the pending list
    const updatedTask = tasks.filter((element, i) => i !== index);
    Settasks(updatedTask);

    // Add the task to the done list
    SetdoneTasks(done => [...done, taskToMove]);
  }

  return (
    <>
      <div>
        <input className="textbox" type="text" placeholder="Enter Homework" value={newtasks} onChange={handle} />
        <button className="btn" onClick={addtask}>Add</button>
        <br />
      </div>

      <div>
        <Cards des="Tasks Pending"></Cards>
        <ol>
          {tasks.map((task, index) => (
            <li key={index}>
              <span className="text">{task}</span>
              <button className="btn" onClick={() => DeleteTask(index)}>🗑</button>
              <button className="btn" onClick={() => Movetodone(index)}>✔</button>
            </li>
          ))}
        </ol>
      </div>

      <div>
        <Cards des="Tasks Done"></Cards>
        <ol>
          {doneTasks.map((task, index) => (
            <li key={index}>
              <span className="text">{task}</span>
            </li>
          ))}
        </ol>
      </div>
    </>
  );
}

export default AddTasks;
