import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Login from './components/login';
import AddTasks from './components/AddTasks';

function App() {
  return (
    <Router>
      <div>
      <div className="dashboard">
        <nav className="navbar">
          <h1>Home work</h1>
          <div>
            <Link to="/login">Login</Link>
            
          </div>
        </nav>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Home />} />
        </Routes>
      </div>
      </div>
    </Router>
  );
}
function Home() {
  return (
  <>
  
  <h2>Welcome</h2>
  <AddTasks></AddTasks>
 
    </>
  );
}

export default App;